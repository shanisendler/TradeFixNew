<?php
// config/data_constants.php

return [
    'hand' => [
        1 => 'יד ראשונה',
        2 => 'יד שניה',
        3 => 'יד שלישית',
        4 => 'יד רביעית'
    ]
];
